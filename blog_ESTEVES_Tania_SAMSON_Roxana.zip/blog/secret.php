<?php
// Initialisation de la BDD
$db=new PDO('mysql:host=localhost;dbname=prjt_blog;port=3306;charset=utf8', 'root', '');

// $db=new PDO('mysql:host=sqletud.u-pem.fr;dbname=tania.esteves_db', 'tania.esteves', 'Bdddetania', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

?>